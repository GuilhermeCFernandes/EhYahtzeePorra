package com.webserver.languages;

import java.io.*;
import java.util.*;
import java.nio.file.*;
import com.webserver.core.*;

public class jpeg extends image {}
