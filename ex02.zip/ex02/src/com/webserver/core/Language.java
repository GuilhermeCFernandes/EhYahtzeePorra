package com.webserver.core;

public interface Language {
	public byte[] execute(String page) throws Exception;
}
